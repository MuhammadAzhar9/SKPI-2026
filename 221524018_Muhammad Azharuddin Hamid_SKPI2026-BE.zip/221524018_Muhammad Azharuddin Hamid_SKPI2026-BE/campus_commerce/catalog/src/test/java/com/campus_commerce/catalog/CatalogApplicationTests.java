package com.campus_commerce.catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
